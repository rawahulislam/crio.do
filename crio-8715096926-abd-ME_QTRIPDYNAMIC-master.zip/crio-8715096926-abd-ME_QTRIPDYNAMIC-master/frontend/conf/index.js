
const config = { backendEndpoint: "http://3.108.240.231:8082" };

export default config;
